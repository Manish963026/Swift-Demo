//
//  RootClass.swift
//  Loginpage
//
//  Created by IE13 on 24/11/23.
//
import Foundation

struct FeedClass: Codable {

    let userId: Int
    let id: Int
    let title: String
    let body: String

}
