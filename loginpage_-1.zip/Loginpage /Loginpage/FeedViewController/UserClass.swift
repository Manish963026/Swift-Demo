//
//  UserClass.swift
//  Loginpage
//
//  Created by IE13 on 24/11/23.
//

import Foundation
struct UserClass: Codable {

    let postId: Int
    let id: Int
    let name: String
    let email: String
    let body: String

}
