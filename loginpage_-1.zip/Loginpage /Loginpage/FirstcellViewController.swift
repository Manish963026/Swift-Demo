//
//  FirstcellViewController.swift
//  Loginpage
//
//  Created by IE13 on 10/11/23.
//

import UIKit

class FirstcellViewController: UITableViewController {
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
}
