//
//  ConstantHandle.swift
//  Loginpage
//
//  Created by IE13 on 20/11/23.
//

import Foundation

struct ConstantHandle {
    static var optionsMessage: String = """
    jRuby is great for
    building desktop applications,
    static websites, data processing services,
    and even automation tools
    """
    static var biometricMessage = "Your device is not configured for biometric authentification."

}
