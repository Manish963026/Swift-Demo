//
//  SecondHomeViewController.swift
//  Loginpage
//
//  Created by IE13 on 21/11/23.
//

import UIKit

class SecondHomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
