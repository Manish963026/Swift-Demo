//
//  HelpCenterViewCell.swift
//  Loginpage
//
//  Created by IE13 on 16/11/23.
//

import UIKit

class HelpCenterViewCell: UITableViewCell {
    @IBOutlet weak var textNameLabel: UILabel!
    @IBOutlet weak var textDescLabel: UILabel!
}
