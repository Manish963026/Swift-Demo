//
//  ProfileTableViewCell.swift
//  Loginpage
//
//  Created by IE13 on 15/11/23.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {
    @IBOutlet weak var profileNameLabel: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
    }

}
