//
//  UserTableViewCell.swift
//  Loginpage
//
//  Created by IE13 on 15/11/23.
//

import UIKit

class UserTableViewCell: UITableViewCell {
    @IBOutlet weak var userLabel: UILabel!
    @IBOutlet weak var imageViews: UIImageView!
}
