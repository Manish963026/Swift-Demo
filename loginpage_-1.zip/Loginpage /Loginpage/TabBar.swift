//
//  TabBar.swift
//  Loginpage
//
//  Created by IE13 on 08/11/23.
//

import UIKit

class TabBar: UITabBarViewController {

}
