//
//  TableViewCellVController.swift
//  Loginpage
//
//  Created by IE13 on 10/11/23.
//

import UIKit

class TableViewCellController: UITableViewCell {

   // @IBOutlet weak var profileLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
