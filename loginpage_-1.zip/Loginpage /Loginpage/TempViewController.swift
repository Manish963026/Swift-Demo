//
//  TempViewController.swift
//  Loginpage
//
//  Created by IE13 on 23/11/23.
//

import UIKit

class TempViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

//        let videoURLWithPath = "http://****/5.m3u8"
//                let videoURL = NSURL(string: videoURLWithPath)
//                playerViewController = AVPlayerViewController()
//
//                dispatch_async(dispatch_get_main_queue()) {
//                    self.playerViewController?.player = AVPlayer.playerWithURL(videoURL) as AVPlayer
//                }
    }
    

   
}
