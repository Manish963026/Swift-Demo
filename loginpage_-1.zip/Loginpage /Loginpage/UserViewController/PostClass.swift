//
//  PostClass.swift
//  Loginpage
//
//  Created by IE13 on 28/11/23.
//

import Foundation

struct PostClass: Codable {

    let id: Int
    let name: String
    let username: String
    let email: String
//    let address: String
//    let phone: String
//    let website: String
//    let company: String

}
