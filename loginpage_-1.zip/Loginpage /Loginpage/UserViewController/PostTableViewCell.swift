//
//  PostTableViewCell.swift
//  Loginpage
//
//  Created by IE13 on 28/11/23.
//

import UIKit

class PostTableViewCell: UITableViewCell {

    @IBOutlet weak var namedLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
