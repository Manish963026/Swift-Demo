//
//  UserdetailTableViewCell.swift
//  Loginpage
//
//  Created by IE13 on 29/11/23.
//

import UIKit

class UserDetailTableViewCell: UITableViewCell {

    @IBOutlet weak var userDetailsLabel: UILabel!
    @IBOutlet weak var userTitleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
