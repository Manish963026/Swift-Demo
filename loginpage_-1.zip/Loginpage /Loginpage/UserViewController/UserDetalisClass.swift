//
//  UserDetalisClass.swift
//  Loginpage
//
//  Created by IE13 on 29/11/23.
//

import Foundation

struct UserDetailsClass: Codable {

    let userId: Int
    let id: Int
    let title: String
    let body: String

}
