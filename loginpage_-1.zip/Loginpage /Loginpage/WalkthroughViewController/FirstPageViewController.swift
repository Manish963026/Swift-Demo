//
//  FirstPageViewController.swift
//  Loginpage
//
//  Created by IE13 on 04/11/23.
//

import UIKit

class FirstPageViewController: UIViewController {
}
